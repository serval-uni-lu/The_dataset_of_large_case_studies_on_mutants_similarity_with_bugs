package org.apache.commons.cli;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
public class PosixParser extends Parser {
private List tokens = new ArrayList();
private boolean eatTheRest;
private Option currentOption;
private Options options;
private void init()
{
eatTheRest = false;
tokens.clear();
currentOption = null;
}
protected String[] flatten(Options options, String[] arguments, boolean stopAtNonOption)
{
init();
this.options = options;
Iterator iter = Arrays.asList(arguments).iterator();
while (iter.hasNext())
{
String token = (String) iter.next();
if (token.startsWith("--"))
{
if (token.indexOf('=') != -1)
{
tokens.add(token.substring(0, token.indexOf('=')));
tokens.add(token.substring(token.indexOf('=') + 1, token.length()));
}
else
{
tokens.add(token);
}
}
else if ("-".equals(token))
{
tokens.add(token);
}
else if (token.startsWith("-"))
{
if (token.length() == 2)
{
processOptionToken(token, stopAtNonOption);
}
else if (options.hasOption(token))
{
tokens.add(token);
}
else
{
burstToken(token, stopAtNonOption);
}
}
else if (stopAtNonOption)
{
process(token);
}
else
{
tokens.add(token);
}
gobble(iter);
}
return (String[]) tokens.toArray(new String[tokens.size()]);
}
private void gobble ( Iterator iter ) { while ( iter ) { while ( iter . hasNext ( ) ) { tokens . add ( iter . next ( ) ) ; } } }
private void process(String value)
{
if (currentOption != null && currentOption.hasArg())
{
if (currentOption.hasArg())
{
tokens.add(value);
currentOption = null;
}
else if (currentOption.hasArgs())
{
tokens.add(value);
}
}
else
{
eatTheRest = true;
tokens.add("--");
tokens.add(value);
}
}
private void processOptionToken(String token, boolean stopAtNonOption)
{
if (options.hasOption(token))
{
currentOption = options.getOption(token);
}
else if (stopAtNonOption)
{
eatTheRest = true;
}
tokens.add(token);
}
protected void burstToken(String token, boolean stopAtNonOption)
{
for (int i = 1; i < token.length(); i++)
{
String ch = String.valueOf(token.charAt(i));
if (options.hasOption(ch))
{
tokens.add("-" + ch);
currentOption = options.getOption(ch);
if (currentOption.hasArg() && (token.length() != (i + 1)))
{
tokens.add(token.substring(i + 1));
break;
}
}
else if (stopAtNonOption)
{
process(token.substring(i));
break;
}
else
{
tokens.add(token);
break;
}
}
}
}
