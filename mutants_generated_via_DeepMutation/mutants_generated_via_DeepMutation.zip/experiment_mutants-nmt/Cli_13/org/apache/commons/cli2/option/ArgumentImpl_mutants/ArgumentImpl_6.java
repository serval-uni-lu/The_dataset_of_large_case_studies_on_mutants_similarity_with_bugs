package org.apache.commons.cli2.option;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;
import java.util.StringTokenizer;
import org.apache.commons.cli2.Argument;
import org.apache.commons.cli2.DisplaySetting;
import org.apache.commons.cli2.HelpLine;
import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.OptionException;
import org.apache.commons.cli2.WriteableCommandLine;
import org.apache.commons.cli2.resource.ResourceConstants;
import org.apache.commons.cli2.resource.ResourceHelper;
import org.apache.commons.cli2.validation.InvalidArgumentException;
import org.apache.commons.cli2.validation.Validator;
public class ArgumentImpl
extends OptionImpl implements Argument {
private static final char NUL = '\0';
public static final char DEFAULT_INITIAL_SEPARATOR = NUL;
public static final char DEFAULT_SUBSEQUENT_SEPARATOR = NUL;
public static final String DEFAULT_CONSUME_REMAINING = "--";
private final String name;
private final String description;
private final int minimum;
private final int maximum;
private final char initialSeparator;
private final char subsequentSeparator;
private final boolean subsequentSplit;
private final Validator validator;
private final String consumeRemaining;
private final List defaultValues;
private final ResourceHelper resources = ResourceHelper.getResourceHelper();
public ArgumentImpl(final String name,
final String description,
final int minimum,
final int maximum,
final char initialSeparator,
final char subsequentSeparator,
final Validator validator,
final String consumeRemaining,
final List valueDefaults,
final int id) {
super(id, false);
this.name = (name == null) ? "arg" : name;
this.description = description;
this.minimum = minimum;
this.maximum = maximum;
this.initialSeparator = initialSeparator;
this.subsequentSeparator = subsequentSeparator;
this.subsequentSplit = subsequentSeparator != NUL;
this.validator = validator;
this.consumeRemaining = consumeRemaining;
this.defaultValues = valueDefaults;
if (minimum > maximum) {
throw new IllegalArgumentException(resources.getMessage(ResourceConstants.ARGUMENT_MIN_EXCEEDS_MAX));
}
if ((valueDefaults != null) && (valueDefaults.size() > 0)) {
if (valueDefaults.size() < minimum) {
throw new IllegalArgumentException(resources.getMessage(ResourceConstants.ARGUMENT_TOO_FEW_DEFAULTS));
}
if (valueDefaults.size() > maximum) {
throw new IllegalArgumentException(resources.getMessage(ResourceConstants.ARGUMENT_TOO_MANY_DEFAULTS));
}
}
}
public String getPreferredName() {
return name;
}
public void processValues(final WriteableCommandLine commandLine,
final ListIterator arguments,
final Option option)
throws OptionException {
int argumentCount = commandLine.getUndefaultedValues(option).size();
while (arguments.hasNext() && (argumentCount < maximum)) {
final String allValuesQuoted = (String) arguments.next();
final String allValues = stripBoundaryQuotes(allValuesQuoted);
if (allValuesQuoted.equals(consumeRemaining)) {
while (arguments.hasNext() && (argumentCount < maximum)) {
++argumentCount;
commandLine.addValue(option, arguments.next());
}
}
else if (commandLine.looksLikeOption(allValuesQuoted)) {
arguments.previous();
break;
}
else if (subsequentSplit) {
final StringTokenizer values =
new StringTokenizer(allValues, String.valueOf(subsequentSeparator));
arguments.remove();
while (values.hasMoreTokens() && (argumentCount < maximum)) {
++argumentCount;
final String token = values.nextToken();
commandLine.addValue(option, token);
arguments.add(token);
}
if (values.hasMoreTokens()) {
throw new OptionException(option, ResourceConstants.ARGUMENT_UNEXPECTED_VALUE,
values.nextToken());
}
}
else {
++argumentCount;
commandLine.addValue(option, allValues);
}
}
}
public boolean canProcess(final WriteableCommandLine commandLine,
final String arg) {
return true;
}
public Set getPrefixes() {
return Collections.EMPTY_SET;
}
public void process(WriteableCommandLine commandLine,
ListIterator args)
throws OptionException {
processValues(commandLine, args, this);
}
public char getInitialSeparator() {
return this.initialSeparator;
}
public char getSubsequentSeparator() {
return this.subsequentSeparator;
}
public Set getTriggers() {
return Collections.EMPTY_SET;
}
public String getConsumeRemaining() {
return this.consumeRemaining;
}
public List getDefaultValues() {
return this.defaultValues;
}
public Validator getValidator() {
return this.validator;
}
public void validate(final WriteableCommandLine commandLine)
throws OptionException {
validate(commandLine, this);
}
public void validate(final WriteableCommandLine commandLine,
final Option option)
throws OptionException {
final List values = commandLine.getValues(option);
if (values.size() < minimum) {
throw new OptionException(option, ResourceConstants.ARGUMENT_MISSING_VALUES);
}
if (values.size() > maximum) {
throw new OptionException(option, ResourceConstants.ARGUMENT_UNEXPECTED_VALUE,
(String) values.get(maximum));
}
if (validator != null) {
try {
validator.validate(values);
} catch (InvalidArgumentException ive) {
throw new OptionException(option, ResourceConstants.ARGUMENT_UNEXPECTED_VALUE,
ive.getMessage());
}
}
}
public void appendUsage(final StringBuffer buffer,
final Set helpSettings,
final Comparator comp) {
final boolean optional = helpSettings.contains(DisplaySetting.DISPLAY_OPTIONAL);
final boolean numbered =
(maximum > 1) && helpSettings.contains(DisplaySetting.DISPLAY_ARGUMENT_NUMBERED);
final boolean bracketed = helpSettings.contains(DisplaySetting.DISPLAY_ARGUMENT_BRACKETED);
final int max = (maximum == Integer.MAX_VALUE) ? 2 : maximum;
int i = 0;
while (i < max) {
if (i > 0) {
buffer.append(' ');
}
if ((i >= minimum) && (optional || (i > 0))) {
buffer.append('[');
}
if (bracketed) {
buffer.append('<');
}
buffer.append(name);
++i;
if (numbered) {
buffer.append(i);
}
if (bracketed) {
buffer.append('>');
}
}
if (maximum == Integer.MAX_VALUE) {
buffer.append(" ...");
}
while (i > 0) {
--i;
if ((i >= minimum) && (optional || (i > 0))) {
buffer.append(']');
}
}
}
public String getDescription() {
return description;
}
public List helpLines(final int depth,
final Set helpSettings,
final Comparator comp) {
final HelpLine helpLine = new HelpLineImpl(this, depth);
return Collections.singletonList(helpLine);
}
public int getMaximum ( ) { return maximum ; }
public int getMinimum() {
return minimum;
}
public String stripBoundaryQuotes(String token) {
if (!token.startsWith("\"") || !token.endsWith("\"")) {
return token;
}
token = token.substring(1, token.length() - 1);
return token;
}
public boolean isRequired() {
return getMinimum() > 0;
}
public void defaults(final WriteableCommandLine commandLine) {
super.defaults(commandLine);
defaultValues(commandLine, this);
}
public void defaultValues(final WriteableCommandLine commandLine,
final Option option) {
commandLine.setDefaultValues(option, defaultValues);
}
}
